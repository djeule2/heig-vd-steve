 #!/bin/sh
PREFIX="/usr/local"
LIB_PREFIX="/usr/lib"

SRC_LIB_PATH="./src"
LIB_NAME="libtrainsim.so"
DEST_LIB_PATH="${PREFIX}/lib"

SRC_INCLUDE_PATH="./src"
INCLUDE_NAME="ctrain_handler.h"
DEST_INCLUDE_PATH="${PREFIX}/include"

LIBTRAINSIM_IDIR="trainsim"
LIBTRAINSIM_LDIR="libtrainsim"

# Install include file
echo "Install includes in ${DEST_INCLUDE_PATH}/${LIBTRAINSIM_IDIR}"
mkdir "${DEST_INCLUDE_PATH}/${LIBTRAINSIM_IDIR}"
cp "${SRC_INCLUDE_PATH}/${INCLUDE_NAME}" "${DEST_INCLUDE_PATH}/${LIBTRAINSIM_IDIR}/"

# Install lib
echo "Install libs in ${DEST_LIB_PATH}/${LIBTRAINSIM_LDIR}"
mkdir "${DEST_LIB_PATH}/${LIBTRAINSIM_LDIR}"
cp "${SRC_LIB_PATH}/${LIB_NAME}" "${DEST_LIB_PATH}/${LIBTRAINSIM_LDIR}/"
ln -s "${DEST_LIB_PATH}/${LIBTRAINSIM_LDIR}/${LIB_NAME}" "${LIB_PREFIX}/${LIB_NAME}"

