 #!/bin/sh
PREFIX="/usr/local"
LIB_PREFIX="/usr/lib"

LIB_NAME="libtrainsim.so"
LIB_PATH="${PREFIX}/lib"

INCLUDE_PATH="${PREFIX}/include"

LIBTRAINSIM_IDIR="trainsim"
LIBTRAINSIM_LDIR="libtrainsim"

# Remove include file
echo "Remove includes : ${INCLUDE_PATH}/${LIBTRAINSIM_IDIR}"
rm -r "${INCLUDE_PATH}/${LIBTRAINSIM_IDIR}"

# Remove lib
echo "Remove libs : ${LIB_PATH}/${LIBTRAINSIM_LDIR}"
rm -r "${LIB_PATH}/${LIBTRAINSIM_LDIR}"
rm "${LIB_PREFIX}/${LIB_NAME}"

