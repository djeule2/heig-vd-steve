%D�termination des probabilit�s (3.1)
clear all;
sprintf('%s', 'Partie pour le code ing�nieur.txt')
file = textread('ingenieur.txt','%s','delimiter','\n','whitespace','');
vector=uint8(file{1,1});
freq = frequency(vector);

[I,Symbol,Proba] = find(freq);
[probamax, Iprobamax] = max(Proba)

sprintf('%s', strcat('Le nombre de symboles dans le texte ingenieur.txt est : ', num2str(length(I))))

for i = 1:length(I)
    sprintf('%s', strcat('Le caract�re : ', char(Symbol(i)-1),' apparait avec une probabilit� de : ', num2str(Proba(i))))
     
end;

%Application de la norme de huffman (3.2)
[zipped,info] = norm2huff(vector);
[Words,Simbols] = huffcodes2bin(info.huffcodes)
for i = 1:length(I)
    %sprintf('%s', info)
     
end;
%function [zipped,info] = norm2huff(vector)



%function vector = huff2norm(zipped,info)
vector2= huff2norm(zipped,info);

vectordouble=double(vector);
vectordouble2=double(vector2);

sum(vectordouble - vectordouble2)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%D�termination des probabilit�s (3.1)
clear all;
sprintf('%s', 'Partie pour le code Huffman.txt')
file = textread('Huffman.txt','%s','delimiter','\n','whitespace','');
vector=uint8(file{1,1});
freq = frequency(vector);

[I,Symbol,Proba] = find(freq);
[probamax, Iprobamax] = max(Proba)

sprintf('%s', strcat('Le nombre de symboles dans le texte Huffman.txt est : ', num2str(length(I))))

for i = 1:length(I)
    sprintf('%s', strcat('Le caract�re : ', char(Symbol(i)-1),' apparait avec une probabilit� de : ', num2str(Proba(i))))
     
end;

%Application de la norme de huffman (3.2)
[zipped,info] = norm2huff(vector);
[Words,Simbols] = huffcodes2bin(info.huffcodes)
for i = 1:length(I)
    %sprintf('%s', info)
     
end;
%function [zipped,info] = norm2huff(vector)



%function vector = huff2norm(zipped,info)
vector2= huff2norm(zipped,info);

vectordouble=double(vector);
vectordouble2=double(vector2);

sum(vectordouble - vectordouble2)