%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;

%%%%%%% Ouverture du fichier texte %%%%%%%%%%%%%%%%
fid = fopen('ing�nieur.txt','rt');
line=0;
ncf=0;
V=1; %%%%%% Introduit une variable V=1 (vrai)
while V
   tline = fgetl(fid); %%%%% On va lire la ligne courante dans le fichier
   line=line+1; %%%%% On incr�mente par 1 le compteur de ligne
   nc=length(tline); %%%%%% On calcule le nombre de caract�res de la ligne courante
   ntline(ncf+1:ncf+nc)=double(tline); %%%%%% On traduit en d�cimal les caract�res de la ligne courantes
   ncf=ncf+nc; %%%%%%%%%%% On incr�mente le compteur de caract�res
   V=ischar(tline); %%%%% On teste si la ligne est une ligne de caract�res 
                    %%%%% Si c'est le cas V=1, si ce n'est plus le cas (caract�re de fin de fichier), V=0
   if (V==0) , break,  end %%%%%% On sort de la boucle while (break) si V=0
   disp(tline) %%%%%%%% On affiche la ligne courante du fichier
   disp(ncf);
end
fclose(fid);

% Le vecteur ntline contient maintenant la s�rie des nombres d�cimaux qui
% repr�sente le fichier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%